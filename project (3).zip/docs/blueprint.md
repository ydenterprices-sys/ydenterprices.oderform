# **App Name**: YD ENTERPRICES ODER FORM APP

## Core Features:

- Product Catalog Management: Admins can add, edit, and view products including name, product code, price, and photo. Automatically generates product descriptions.
- Customer Relationship Management (CRM): Admins can add, edit, and view customer details, creating a database of business contacts.
- Order Creation Flow: Users can select a customer, browse available products, and add items to an order with a specified quantity using an intuitive '+' button.
- Product Search: Search products efficiently by name or product code to quickly access details and add to orders.
- Daily Order Overview: View a comprehensive list of all orders placed on a specific day, facilitating daily operational reviews.
- Customer-wise Order History: Access and review a complete history of past orders associated with any specific customer.
- Daily Sales Reporting: Generate a summary of daily sales based on completed orders to track performance.

## Style Guidelines:

- Primary brand color: A refined and trustworthy medium blue (#2E7EB8), signifying reliability and professionalism.
- Background color: A very subtle, cool light gray-blue (#EBF3F8), providing a clean and non-distracting canvas for content.
- Accent color: A crisp, bright aqua (#45DBDB) for interactive elements, highlights, and calls-to-action, adding a touch of modern dynamism.
- All text will use 'Inter', a clean and versatile sans-serif font, for excellent readability and a modern, professional appearance across headlines and body text.
- The application's title, 'YD Order Hub', will be prominently displayed at the top of every page for immediate brand recognition and navigation.
- Use clear, universally recognizable icons for actions like 'add', 'edit', 'search', and 'quantity adjustment' ('+').