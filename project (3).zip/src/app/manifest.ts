import { MetadataRoute } from 'next'
import { COMPANY_CONFIG } from '@/lib/company-config'

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: COMPANY_CONFIG.name,
    short_name: 'YD Hub',
    description: COMPANY_CONFIG.tagline,
    start_url: '/',
    display: 'standalone',
    background_color: '#f1f5f9',
    theme_color: '#2563eb',
    icons: [
      {
        src: 'https://picsum.photos/seed/ydicon/192/192',
        sizes: '192x192',
        type: 'image/png',
      },
      {
        src: 'https://picsum.photos/seed/ydicon/512/512',
        sizes: '512x512',
        type: 'image/png',
      },
    ],
  }
}
