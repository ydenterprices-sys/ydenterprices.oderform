"use client";

import { useState } from "react";
import { Shell } from "@/components/layout/Shell";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Search, UserPlus, Phone, Mail, MapPin, ExternalLink } from "lucide-react";
import Link from "next/link";

// Mock data
const MOCK_CUSTOMERS = [
  { id: "C001", name: "Acme Corp Solutions", contact: "John Doe", email: "john@acme.com", phone: "+1 555-0123", city: "New York" },
  { id: "C002", name: "Global Tech Inc", contact: "Sarah Miller", email: "sarah@globaltech.io", phone: "+1 555-0124", city: "San Francisco" },
  { id: "C003", name: "Starlight Retailers", contact: "Mike Johnson", email: "mike@starlight.com", phone: "+1 555-0125", city: "Chicago" },
  { id: "C004", name: "Pioneer Logistics", contact: "Emily Davis", email: "emily@pioneer.com", phone: "+1 555-0126", city: "Houston" },
  { id: "C005", name: "Vertex Consulting", contact: "Robert Brown", email: "robert@vertex.net", phone: "+1 555-0127", city: "Atlanta" },
];

export default function CustomersPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [customers] = useState(MOCK_CUSTOMERS);

  const filteredCustomers = customers.filter(
    (c) => 
      c.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
      c.contact.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <Shell>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-primary font-headline">Customer CRM</h1>
            <p className="text-muted-foreground">Manage your business contacts and client database.</p>
          </div>
          <Link href="/customers/new">
            <Button className="w-full sm:w-auto gap-2">
              <UserPlus className="h-4 w-4" />
              Add Customer
            </Button>
          </Link>
        </div>

        <div className="relative">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input 
            placeholder="Search by company name, contact, or customer ID..." 
            className="pl-10 h-12 shadow-sm border-primary/20"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        <Card className="border-none shadow-md overflow-hidden">
          <Table>
            <TableHeader className="bg-muted/50">
              <TableRow>
                <TableHead className="w-[100px]">ID</TableHead>
                <TableHead>Company & Contact</TableHead>
                <TableHead>Communication</TableHead>
                <TableHead>Location</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredCustomers.map((customer) => (
                <TableRow key={customer.id} className="hover:bg-primary/5 transition-colors">
                  <TableCell className="font-mono text-xs font-semibold text-primary">{customer.id}</TableCell>
                  <TableCell>
                    <div className="flex flex-col">
                      <span className="font-bold text-lg">{customer.name}</span>
                      <span className="text-sm text-muted-foreground">{customer.contact}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex flex-col gap-1">
                      <div className="flex items-center gap-2 text-xs">
                        <Mail className="h-3 w-3 text-accent" />
                        {customer.email}
                      </div>
                      <div className="flex items-center gap-2 text-xs">
                        <Phone className="h-3 w-3 text-accent" />
                        {customer.phone}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2 text-sm">
                      <MapPin className="h-3 w-3 text-muted-foreground" />
                      {customer.city}
                    </div>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="sm" asChild>
                      <Link href={`/customers/${customer.id}`} className="gap-2">
                        View Orders
                        <ExternalLink className="h-3 w-3" />
                      </Link>
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
              {filteredCustomers.length === 0 && (
                <TableRow>
                  <TableCell colSpan={5} className="h-24 text-center text-muted-foreground">
                    No customers found matching your search criteria.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </Card>
      </div>
    </Shell>
  );
}