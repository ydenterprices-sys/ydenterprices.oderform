"use client";

import { use } from "react";
import { Shell } from "@/components/layout/Shell";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ChevronLeft, Mail, Phone, MapPin, ShoppingBag, Calendar, History, ExternalLink } from "lucide-react";
import Link from "next/link";

// Mock data lookup
const MOCK_CUSTOMERS: Record<string, any> = {
  "C001": { id: "C001", name: "Acme Corp Solutions", contact: "John Doe", email: "john@acme.com", phone: "+1 555-0123", city: "New York", address: "123 Business Way, Suite 100" },
  "C002": { id: "C002", name: "Global Tech Inc", contact: "Sarah Miller", email: "sarah@globaltech.io", phone: "+1 555-0124", city: "San Francisco", address: "500 Innovation Blvd" },
  "C003": { id: "C003", name: "Starlight Retailers", contact: "Mike Johnson", email: "mike@starlight.com", phone: "+1 555-0125", city: "Chicago", address: "88 Retail Row" },
  "C004": { id: "C004", name: "Pioneer Logistics", contact: "Emily Davis", email: "emily@pioneer.com", phone: "+1 555-0126", city: "Houston", address: "10 Logistics Lane" },
  "C005": { id: "C005", name: "Vertex Consulting", contact: "Robert Brown", email: "robert@vertex.net", phone: "+1 555-0127", city: "Atlanta", address: "77 Consulting Plaza" },
};

const MOCK_ORDERS = [
  { id: "ORD-9281", date: "2024-03-20", total: 145000.00, items: 12, status: "Delivered" },
  { id: "ORD-8812", date: "2024-02-15", total: 32000.00, items: 2, status: "Delivered" },
  { id: "ORD-7654", date: "2024-01-10", total: 89050.50, items: 5, status: "Delivered" },
];

export default function CustomerDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const customer = MOCK_CUSTOMERS[id] || MOCK_CUSTOMERS["C001"];

  return (
    <Shell>
      <div className="max-w-5xl mx-auto space-y-8">
        <Link href="/customers" className="flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors">
          <ChevronLeft className="h-4 w-4" />
          Back to CRM
        </Link>

        <div className="flex flex-col md:flex-row justify-between items-start gap-6">
          <div className="space-y-1">
            <div className="flex items-center gap-3">
              <h1 className="text-3xl font-bold text-primary font-headline">{customer.name}</h1>
              <span className="px-2 py-0.5 rounded bg-primary/10 text-primary text-xs font-mono font-bold">{customer.id}</span>
            </div>
            <p className="text-muted-foreground">Active account since January 2024</p>
          </div>
          <div className="flex gap-2 w-full md:w-auto">
            <Link href="/orders/new" className="flex-1">
              <Button className="w-full gap-2">
                <ShoppingBag className="h-4 w-4" />
                Create New Order
              </Button>
            </Link>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="md:col-span-1 border-none shadow-md">
            <CardHeader>
              <CardTitle className="text-lg">Contact Info</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="mt-1 p-2 bg-muted rounded-full">
                  <History className="h-4 w-4 text-muted-foreground" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground uppercase font-bold tracking-wider">Primary Contact</p>
                  <p className="font-semibold">{customer.contact}</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="mt-1 p-2 bg-muted rounded-full">
                  <Mail className="h-4 w-4 text-muted-foreground" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground uppercase font-bold tracking-wider">Email</p>
                  <p className="font-semibold">{customer.email}</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="mt-1 p-2 bg-muted rounded-full">
                  <Phone className="h-4 w-4 text-muted-foreground" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground uppercase font-bold tracking-wider">Phone</p>
                  <p className="font-semibold">{customer.phone}</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="mt-1 p-2 bg-muted rounded-full">
                  <MapPin className="h-4 w-4 text-muted-foreground" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground uppercase font-bold tracking-wider">Location</p>
                  <p className="font-semibold">{customer.address}, {customer.city}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="md:col-span-2 border-none shadow-md">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <History className="h-5 w-5 text-primary" />
                Order History
              </CardTitle>
              <CardDescription>Review all previous transactions for this customer.</CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader className="bg-muted/30">
                  <TableRow>
                    <TableHead>Order ID</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Items</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Total</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {MOCK_ORDERS.map((order) => (
                    <TableRow key={order.id}>
                      <TableCell className="font-mono text-xs font-bold text-primary">{order.id}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2 text-sm">
                          <Calendar className="h-3 w-3 text-muted-foreground" />
                          {order.date}
                        </div>
                      </TableCell>
                      <TableCell>{order.items}</TableCell>
                      <TableCell>
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase bg-green-100 text-green-700">
                          {order.status}
                        </span>
                      </TableCell>
                      <TableCell className="text-right font-bold">Rs. {order.total.toLocaleString(undefined, { minimumFractionDigits: 2 })}</TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm" asChild>
                          <Link href={`/orders/${order.id}`}>
                            <ExternalLink className="h-4 w-4" />
                          </Link>
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              <div className="p-4 bg-muted/20 text-center">
                <p className="text-xs text-muted-foreground font-medium">Showing last 3 orders. Total lifetime value: Rs. 266,050.50</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </Shell>
  );
}
