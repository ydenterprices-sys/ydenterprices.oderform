"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Shell } from "@/components/layout/Shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Search, Plus, Minus, ShoppingCart, ArrowRight, User, Package, Trash2, CheckCircle2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import Image from "next/image";
import Link from "next/link";

const MOCK_CUSTOMERS = [
  { id: "C001", name: "Acme Corp Solutions" },
  { id: "C002", name: "Global Tech Inc" },
  { id: "C003", name: "Starlight Retailers" },
];

const MOCK_PRODUCTS = [
  { 
    id: "1", 
    name: "Ultra-Light Laptop", 
    code: "PRO-001", 
    photo: "https://picsum.photos/seed/elec1/600/400",
    variants: [
      { size: "13-inch", price: 129999.00 },
      { size: "15-inch", price: 149999.00 },
      { size: "16-inch Pro", price: 189999.00 }
    ]
  },
  { 
    id: "2", 
    name: "Noise Cancelling Headphones", 
    code: "PRO-002", 
    photo: "https://picsum.photos/seed/elec2/600/400",
    variants: [
      { size: "Standard", price: 29999.00 },
      { size: "Premium Edition", price: 39999.00 }
    ]
  },
  { 
    id: "3", 
    name: "Mechanical Keyboard", 
    code: "PRO-003", 
    photo: "https://picsum.photos/seed/elec3/600/400",
    variants: [
      { size: "60% Compact", price: 12500.00 },
      { size: "Tenkeyless", price: 14500.00 },
      { size: "Full Size", price: 16500.00 }
    ]
  },
  { 
    id: "4", 
    name: "Ergonomic Mouse", 
    code: "PRO-004", 
    photo: "https://picsum.photos/seed/elec4/600/400",
    variants: [
      { size: "Standard", price: 7999.00 },
      { size: "XL Performance", price: 9999.00 }
    ]
  },
  { 
    id: "5", 
    name: "4K Monitor", 
    code: "PRO-005", 
    photo: "https://picsum.photos/seed/elec5/600/400",
    variants: [
      { size: "27-inch", price: 44900.00 },
      { size: "32-inch", price: 59900.00 }
    ]
  },
];

export default function NewOrderPage() {
  const router = useRouter();
  const { toast } = useToast();
  const [step, setStep] = useState(1); // 1: Customer, 2: Products
  const [selectedCustomerId, setSelectedCustomerId] = useState("");
  const [orderItems, setOrderItems] = useState<any[]>([]);
  const [productSearch, setProductSearch] = useState("");
  const [selectedVariants, setSelectedVariants] = useState<Record<string, string>>({});

  const selectedCustomer = MOCK_CUSTOMERS.find(c => c.id === selectedCustomerId);

  const handleVariantChange = (productId: string, size: string) => {
    setSelectedVariants(prev => ({ ...prev, [productId]: size }));
  };

  const addToOrder = (product: any) => {
    const selectedSize = selectedVariants[product.id] || product.variants[0].size;
    const variant = product.variants.find((v: any) => v.size === selectedSize);
    
    const itemKey = `${product.id}-${selectedSize}`;
    const existing = orderItems.find(item => item.itemKey === itemKey);

    if (existing) {
      setOrderItems(orderItems.map(item => 
        item.itemKey === itemKey ? { ...item, quantity: item.quantity + 1 } : item
      ));
    } else {
      setOrderItems([...orderItems, { 
        ...product, 
        itemKey,
        size: selectedSize, 
        price: variant.price,
        quantity: 1 
      }]);
    }

    toast({
      title: "Added to cart",
      description: `${product.name} (${selectedSize}) added to order.`,
    });
  };

  const updateQuantity = (itemKey: string, delta: number) => {
    setOrderItems(orderItems.map(item => {
      if (item.itemKey === itemKey) {
        const newQty = Math.max(1, item.quantity + delta);
        return { ...item, quantity: newQty };
      }
      return item;
    }));
  };

  const removeItem = (itemKey: string) => {
    setOrderItems(orderItems.filter(item => item.itemKey !== itemKey));
  };

  const totalAmount = orderItems.reduce((acc, item) => acc + (item.price * item.quantity), 0);

  const handleSubmitOrder = () => {
    toast({
      title: "Order Created!",
      description: `Order successfully placed for ${selectedCustomer?.name}.`,
    });
    router.push("/orders");
  };

  const filteredProducts = MOCK_PRODUCTS.filter(p => 
    p.name.toLowerCase().includes(productSearch.toLowerCase()) || 
    p.code.toLowerCase().includes(productSearch.toLowerCase())
  );

  return (
    <Shell>
      <div className="max-w-7xl mx-auto space-y-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-primary font-headline">Create New Order</h1>
            <p className="text-muted-foreground">Step {step} of 2: {step === 1 ? "Select Customer" : "Add Products"}</p>
          </div>
          <div className="flex gap-2">
            {[1, 2].map((i) => (
              <div key={i} className={`h-2 w-12 rounded-full ${step >= i ? "bg-primary" : "bg-muted"}`} />
            ))}
          </div>
        </div>

        {step === 1 && (
          <Card className="border-none shadow-xl max-w-xl mx-auto">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="h-5 w-5 text-primary" />
                Who is this order for?
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <label className="text-sm font-medium">Select Customer</label>
                <Select onValueChange={setSelectedCustomerId} value={selectedCustomerId}>
                  <SelectTrigger className="h-12">
                    <SelectValue placeholder="Search for a customer..." />
                  </SelectTrigger>
                  <SelectContent>
                    {MOCK_CUSTOMERS.map(c => (
                      <SelectItem key={c.id} value={c.id}>{c.name} ({c.id})</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="p-4 bg-muted/30 rounded-lg text-sm text-muted-foreground">
                <p>New customer? <Link href="/customers/new" className="text-primary hover:underline font-semibold">Register them first</Link></p>
              </div>
            </CardContent>
            <CardFooter>
              <Button 
                className="w-full h-12 gap-2" 
                disabled={!selectedCustomerId}
                onClick={() => setStep(2)}
              >
                Continue to Products
                <ArrowRight className="h-4 w-4" />
              </Button>
            </CardFooter>
          </Card>
        )}

        {step === 2 && (
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            <div className="lg:col-span-3 space-y-6">
              <Card className="border-none shadow-md">
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Package className="h-5 w-5 text-primary" />
                      Browse Catalog
                    </CardTitle>
                    <div className="relative w-full max-w-xs">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input 
                        placeholder="Search products..." 
                        className="pl-10 h-9" 
                        value={productSearch}
                        onChange={(e) => setProductSearch(e.target.value)}
                      />
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="p-0">
                  <div className="divide-y">
                    {filteredProducts.map(product => {
                      const currentSize = selectedVariants[product.id] || product.variants[0].size;
                      const currentPrice = product.variants.find(v => v.size === currentSize)?.price || 0;
                      
                      return (
                        <div key={product.id} className="p-6 flex flex-col md:flex-row items-center justify-between hover:bg-muted/30 transition-colors gap-6">
                          <div className="flex items-center gap-8 flex-1">
                            <div className="relative h-[200px] w-[200px] rounded-lg overflow-hidden bg-muted border-2 shadow-sm shrink-0">
                              <Image src={product.photo} alt={product.name} fill className="object-cover" />
                            </div>
                            <div className="space-y-4 flex-1">
                              <div>
                                <h3 className="font-bold text-2xl">{product.name}</h3>
                                <p className="text-sm text-muted-foreground font-mono bg-muted inline-block px-2 py-0.5 rounded">
                                  Code: {product.code}
                                </p>
                              </div>

                              <div className="space-y-2">
                                <Label className="text-xs font-black uppercase text-muted-foreground">Select Size</Label>
                                <RadioGroup 
                                  value={currentSize} 
                                  onValueChange={(val) => handleVariantChange(product.id, val)}
                                  className="flex flex-wrap gap-2"
                                >
                                  {product.variants.map((variant) => (
                                    <div key={variant.size} className="flex items-center">
                                      <RadioGroupItem value={variant.size} id={`size-${product.id}-${variant.size}`} className="sr-only" />
                                      <Label
                                        htmlFor={`size-${product.id}-${variant.size}`}
                                        className={`px-3 py-1.5 rounded-md border text-xs font-bold cursor-pointer transition-all ${
                                          currentSize === variant.size 
                                            ? "bg-primary text-white border-primary" 
                                            : "bg-white hover:border-primary"
                                        }`}
                                      >
                                        {variant.size} - Rs. {variant.price.toLocaleString()}
                                      </Label>
                                    </div>
                                  ))}
                                </RadioGroup>
                              </div>
                            </div>
                          </div>
                          <div className="text-center md:text-right space-y-4 min-w-[150px]">
                            <div className="text-3xl font-black text-primary">Rs. {currentPrice.toLocaleString()}</div>
                            <Button 
                              size="lg" 
                              variant="outline" 
                              className="w-full gap-2 border-primary text-primary hover:bg-primary hover:text-white font-bold"
                              onClick={() => addToOrder(product)}
                            >
                              <Plus className="h-5 w-5" />
                              Add to Order
                            </Button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="space-y-6">
              <Card className="border-none shadow-lg sticky top-24">
                <CardHeader className="bg-primary text-white rounded-t-lg">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <ShoppingCart className="h-5 w-5" />
                      Current Order
                    </CardTitle>
                    <span className="text-xs bg-white/20 px-2 py-0.5 rounded-full">{orderItems.length} items</span>
                  </div>
                  <p className="text-xs text-white/70 mt-1">For: {selectedCustomer?.name}</p>
                </CardHeader>
                <CardContent className="p-0 max-h-[500px] overflow-auto">
                  {orderItems.length > 0 ? (
                    <div className="divide-y">
                      {orderItems.map(item => (
                        <div key={item.itemKey} className="p-4 space-y-2">
                          <div className="flex justify-between items-start">
                            <div className="flex flex-col">
                              <span className="text-sm font-semibold pr-2">{item.name}</span>
                              <span className="text-[10px] text-primary font-bold uppercase">{item.size}</span>
                            </div>
                            <button onClick={() => removeItem(item.itemKey)} className="text-muted-foreground hover:text-destructive">
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </div>
                          <div className="flex justify-between items-center">
                            <div className="flex items-center border rounded-md">
                              <button onClick={() => updateQuantity(item.itemKey, -1)} className="p-1 hover:bg-muted"><Minus className="h-3 w-3" /></button>
                              <span className="px-3 text-sm font-bold">{item.quantity}</span>
                              <button onClick={() => updateQuantity(item.itemKey, 1)} className="p-1 hover:bg-muted"><Plus className="h-3 w-3" /></button>
                            </div>
                            <span className="text-sm font-bold text-primary">Rs. {(item.price * item.quantity).toLocaleString()}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="p-10 text-center text-muted-foreground">
                      <ShoppingCart className="h-8 w-8 mx-auto mb-2 opacity-20" />
                      <p className="text-sm">Your order is currently empty.</p>
                    </div>
                  )}
                </CardContent>
                <CardFooter className="flex flex-col border-t p-4 gap-4 bg-muted/20">
                  <div className="flex justify-between items-center w-full">
                    <span className="text-muted-foreground font-medium uppercase text-xs tracking-wider">Subtotal</span>
                    <span className="text-xl font-black">Rs. {totalAmount.toLocaleString()}</span>
                  </div>
                  <Button 
                    className="w-full h-12 bg-accent text-accent-foreground hover:opacity-90 gap-2 font-bold shadow-lg"
                    disabled={orderItems.length === 0}
                    onClick={handleSubmitOrder}
                  >
                    <CheckCircle2 className="h-5 w-5" />
                    Complete Order
                  </Button>
                  <Button variant="ghost" className="w-full text-xs" onClick={() => setStep(1)}>
                    Change Customer
                  </Button>
                </CardFooter>
              </Card>
            </div>
          </div>
        )}
      </div>
    </Shell>
  );
}
