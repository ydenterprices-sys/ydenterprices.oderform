"use client";

import { useState, useEffect } from "react";
import { Shell } from "@/components/layout/Shell";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Calendar as CalendarIcon, Filter, TrendingUp, ShoppingBag, User, ExternalLink, Printer, BarChart3, Layers, Trash2, Truck, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import Link from "next/link";
import { COMPANY_CONFIG } from "@/lib/company-config";

// Enhanced Mock data with Supplier info
const INITIAL_ORDERS = [
  { 
    id: "ORD-9281", 
    customer: "Acme Corp Solutions", 
    total: 145000.00, 
    itemsCount: 12, 
    time: "10:30 AM", 
    status: "Delivered",
    details: [
      { name: "Ultra-Light Laptop", size: "13-inch", qty: 1, price: 129999.00, supplier: "Apex Tech Supplies" },
      { name: "Mechanical Keyboard", size: "Tenkeyless", qty: 1, price: 15001.00, supplier: "Starlight Manufacturing" }
    ]
  },
  { 
    id: "ORD-9282", 
    customer: "Global Tech Inc", 
    total: 89050.00, 
    itemsCount: 5, 
    time: "11:15 AM", 
    status: "Processing",
    details: [
      { name: "Noise Cancelling Headphones", size: "Premium Edition", qty: 2, price: 29999.00, supplier: "Apex Tech Supplies" },
      { name: "Ergonomic Mouse", size: "Standard", qty: 3, price: 9684.00, supplier: "Global Logistics Ltd" }
    ]
  },
  { 
    id: "ORD-9283", 
    customer: "Starlight Retailers", 
    total: 240000.00, 
    itemsCount: 25, 
    time: "01:45 PM", 
    status: "Pending",
    details: [
      { name: "4K Monitor", size: "32-inch", qty: 5, price: 44900.00, supplier: "Apex Tech Supplies" },
      { name: "Mechanical Keyboard", size: "Full Size", qty: 1, price: 15500.00, supplier: "Starlight Manufacturing" }
    ]
  },
];

export default function OrdersOverviewPage() {
  const { toast } = useToast();
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [orders, setOrders] = useState(INITIAL_ORDERS);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  const handleDeleteOrder = (id: string) => {
    setOrders(orders.filter(o => o.id !== id));
    toast({
      title: "Order Deleted",
      description: `Order ${id} has been removed from the system.`,
      variant: "destructive"
    });
  };

  const dailyTotal = orders.reduce((acc, o) => acc + o.total, 0);
  const totalUnits = orders.reduce((acc, o) => acc + o.details.reduce((sum, d) => sum + d.qty, 0), 0);

  // Grouping by Supplier (for Item Distribution table)
  const supplierSummary = orders.reduce((acc: any, order) => {
    order.details.forEach(item => {
      const supplierName = item.supplier || "Unknown Supplier";
      const productKey = `${item.name} (${item.size})`;
      
      if (!acc[supplierName]) {
        acc[supplierName] = {};
      }
      if (!acc[supplierName][productKey]) {
        acc[supplierName][productKey] = { name: item.name, size: item.size, qty: 0 };
      }
      acc[supplierName][productKey].qty += item.qty;
    });
    return acc;
  }, {});

  // Grouping by Customer (for Customer Details section)
  const customerSummary = orders.reduce((acc: any, order) => {
    if (!acc[order.customer]) {
      acc[order.customer] = { orders: [], items: [], total: 0 };
    }
    acc[order.customer].orders.push(order.id);
    acc[order.customer].total += order.total;
    order.details.forEach(d => {
      acc[order.customer].items.push({ name: d.name, size: d.size, qty: d.qty });
    });
    return acc;
  }, {});

  const handlePrintReport = () => {
    window.print();
  };

  return (
    <Shell>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 print:hidden">
          <div>
            <h1 className="text-3xl font-bold text-primary font-headline">Order Management</h1>
            <p className="text-muted-foreground">Monitor daily sales and review historical orders.</p>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="default" className="gap-2 bg-primary hover:bg-primary/90 shadow-md" onClick={handlePrintReport}>
              <Printer className="h-4 w-4" />
              Print Daily Report
            </Button>
          </div>
        </div>

        {/* Print-Only Header */}
        <div className="hidden print:block border-b-2 border-primary pb-6 mb-8">
          <div className="flex justify-between items-end">
            <div>
              <h1 className="text-4xl font-black text-primary font-headline italic tracking-tighter uppercase">{COMPANY_CONFIG.name}</h1>
              <p className="text-lg font-bold text-muted-foreground tracking-[0.2em] mt-2 uppercase">Official Daily Sales Report</p>
            </div>
            <div className="text-right">
              <p className="text-sm font-black uppercase text-primary">Report Date</p>
              <p className="text-2xl font-bold">{date}</p>
            </div>
          </div>
          
          <div className="grid grid-cols-3 gap-6 mt-8 bg-muted/10 p-6 rounded-lg border">
            <div>
              <p className="text-sm font-black uppercase text-muted-foreground mb-1">Total Revenue</p>
              <p className="text-3xl font-black text-primary">Rs. {dailyTotal.toLocaleString()}</p>
            </div>
            <div>
              <p className="text-sm font-black uppercase text-muted-foreground mb-1">Orders Processed</p>
              <p className="text-3xl font-black text-primary">{orders.length}</p>
            </div>
            <div>
              <p className="text-sm font-black uppercase text-muted-foreground mb-1">Units Distributed</p>
              <p className="text-3xl font-black text-primary">{totalUnits}</p>
            </div>
          </div>
        </div>

        {/* Print-Only Supplier-wise Distribution */}
        <div className="hidden print:block mb-10">
          <h2 className="text-2xl font-black uppercase tracking-widest text-primary mb-6 flex items-center gap-3">
            <Truck className="h-6 w-6" />
            Supplier Distribution
          </h2>
          {Object.entries(supplierSummary).map(([supplier, items]: [string, any]) => (
            <div key={supplier} className="mb-8">
              <h3 className="text-xl font-bold bg-muted/50 px-4 py-2 border-l-4 border-primary mb-3 uppercase tracking-wide">{supplier}</h3>
              <Table className="border text-sm">
                <TableHeader className="bg-muted/30">
                  <TableRow>
                    <TableHead className="font-bold py-3">Product Description</TableHead>
                    <TableHead className="font-bold py-3">Size</TableHead>
                    <TableHead className="text-right font-bold py-3">Total Qty</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {Object.values(items).map((item: any, idx) => (
                    <TableRow key={idx}>
                      <TableCell className="py-2 font-medium">{item.name}</TableCell>
                      <TableCell className="py-2">
                        <span className="px-2 py-0.5 rounded bg-muted text-xs font-bold uppercase">{item.size}</span>
                      </TableCell>
                      <TableCell className="text-right font-bold py-2 text-base">{item.qty}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ))}
        </div>

        {/* Print-Only Customer-wise Details */}
        <div className="hidden print:block mb-10">
          <h2 className="text-2xl font-black uppercase tracking-widest text-primary mb-6 flex items-center gap-3">
            <Users className="h-6 w-6" />
            Customer Distribution
          </h2>
          <div className="grid grid-cols-2 gap-6">
            {Object.entries(customerSummary).map(([customer, data]: [string, any]) => (
              <div key={customer} className="border-2 rounded-xl p-4 bg-muted/5">
                <div className="flex justify-between items-center mb-3 border-b-2 pb-2">
                  <h3 className="text-lg font-black text-primary uppercase">{customer}</h3>
                  <div className="text-right">
                    <p className="text-[10px] font-bold text-muted-foreground uppercase leading-none">Revenue</p>
                    <p className="text-base font-bold">Rs. {data.total.toLocaleString()}</p>
                  </div>
                </div>
                <div className="space-y-3">
                  <div className="flex flex-wrap gap-1.5">
                    {data.orders.map((id: string) => (
                      <span key={id} className="text-[10px] font-mono font-bold bg-primary/10 text-primary px-2 py-0.5 rounded">
                        {id}
                      </span>
                    ))}
                  </div>
                  <ul className="text-sm space-y-2">
                    {data.items.map((item: any, idx: number) => (
                      <li key={idx} className="flex justify-between border-b border-dashed border-muted pb-1.5">
                        <span className="truncate max-w-[200px] font-medium">
                          {item.name} <span className="text-muted-foreground text-xs font-bold">({item.size})</span>
                        </span>
                        <span className="font-black shrink-0 ml-2">x{item.qty}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* UI Elements - Hidden in Print */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 print:hidden">
          <Card className="border-none shadow-md bg-primary text-white">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium opacity-80 uppercase tracking-widest">Daily Sales Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-black">Rs. {dailyTotal.toLocaleString()}</div>
              <p className="text-xs opacity-70 mt-1 flex items-center gap-1">
                <TrendingUp className="h-3 w-3" />
                Across {orders.length} orders today
              </p>
            </CardContent>
          </Card>
          <Card className="border-none shadow-md">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground uppercase tracking-widest">Average Order Value</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-black">Rs. {(dailyTotal / (orders.length || 1)).toLocaleString(undefined, { maximumFractionDigits: 0 })}</div>
              <p className="text-xs text-muted-foreground mt-1">Updated in real-time</p>
            </CardContent>
          </Card>
          <Card className="border-none shadow-md border-2 border-primary/20">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground uppercase tracking-widest">Select Review Date</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                <CalendarIcon className="h-4 w-4 text-primary" />
                <input 
                  type="date" 
                  className="h-9 border-none bg-muted focus:ring-0 font-bold text-primary rounded-md px-2" 
                  value={date} 
                  onChange={(e) => setDate(e.target.value)}
                />
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="daily" className="w-full print:hidden">
          <TabsList className="bg-card shadow-sm border p-1 h-12">
            <TabsTrigger value="daily" className="gap-2 h-10 px-6 data-[state=active]:bg-primary data-[state=active]:text-white font-bold">
              <ShoppingBag className="h-4 w-4" />
              Daily Orders
            </TabsTrigger>
            <TabsTrigger value="customers" className="gap-2 h-10 px-6 data-[state=active]:bg-primary data-[state=active]:text-white font-bold">
              <Users className="h-4 w-4" />
              Customer History
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="daily" className="mt-6">
            <Card className="border-none shadow-md overflow-hidden">
              <CardHeader className="flex flex-row items-center justify-between border-b bg-muted/20">
                <div>
                  <CardTitle className="text-xl font-bold flex items-center gap-2">
                    <BarChart3 className="h-5 w-5 text-primary" />
                    Transaction Log
                  </CardTitle>
                  <CardDescription>All orders placed on {date}.</CardDescription>
                </div>
                <Button variant="outline" size="sm" className="gap-2">
                  <Filter className="h-4 w-4" />
                  Filter
                </Button>
              </CardHeader>
              <CardContent className="p-0">
                <Table>
                  <TableHeader className="bg-muted/50">
                    <TableRow>
                      <TableHead className="font-black uppercase text-[10px] tracking-widest">Order ID</TableHead>
                      <TableHead className="font-black uppercase text-[10px] tracking-widest">Customer</TableHead>
                      <TableHead className="font-black uppercase text-[10px] tracking-widest text-center">Items</TableHead>
                      <TableHead className="font-black uppercase text-[10px] tracking-widest">Time</TableHead>
                      <TableHead className="font-black uppercase text-[10px] tracking-widest">Status</TableHead>
                      <TableHead className="text-right font-black uppercase text-[10px] tracking-widest">Total</TableHead>
                      <TableHead className="text-right font-black uppercase text-[10px] tracking-widest">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {orders.map((order) => (
                      <TableRow key={order.id} className="hover:bg-primary/5 transition-colors">
                        <TableCell className="font-mono text-xs font-bold text-primary">{order.id}</TableCell>
                        <TableCell className="font-bold">{order.customer}</TableCell>
                        <TableCell className="text-center">{order.itemsCount}</TableCell>
                        <TableCell className="text-muted-foreground text-xs">{order.time}</TableCell>
                        <TableCell>
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                            order.status === 'Delivered' ? 'bg-green-100 text-green-700' : 
                            order.status === 'Processing' ? 'bg-blue-100 text-blue-700' : 
                            'bg-yellow-100 text-yellow-700'
                          }`}>
                            {order.status}
                          </span>
                        </TableCell>
                        <TableCell className="text-right font-black font-mono text-primary">Rs. {order.total.toLocaleString()}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-1">
                            <Button variant="ghost" size="sm" asChild title="View Details">
                              <Link href={`/orders/${order.id}`}>
                                <ExternalLink className="h-4 w-4" />
                              </Link>
                            </Button>
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button variant="ghost" size="sm" title="Delete Order" className="text-destructive hover:text-destructive hover:bg-destructive/10">
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>Delete Order {order.id}?</AlertDialogTitle>
                                  <AlertDialogDescription>
                                    This action cannot be undone. This will permanently remove the order record from the system.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                                  <AlertDialogAction onClick={() => handleDeleteOrder(order.id)} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                                    Delete Order
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                    {orders.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={7} className="h-24 text-center text-muted-foreground">
                          No orders found for this date.
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="customers" className="mt-6">
            <Card className="border-none shadow-md">
              <CardHeader>
                <CardTitle>Customer-wise History</CardTitle>
                <CardDescription>Select a customer to see their complete purchase history.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex gap-4">
                  <Input placeholder="Search customer history..." className="max-w-md h-10 border-primary/20" />
                  <Button className="font-bold">Search</Button>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {[
                    { name: 'Acme Corp Solutions', id: 'C001' },
                    { name: 'Global Tech Inc', id: 'C002' },
                    { name: 'Starlight Retailers', id: 'C003' }
                  ].map(customer => (
                    <Link href={`/customers/${customer.id}`} key={customer.id}>
                      <div className="p-5 rounded-lg border-2 border-transparent hover:border-primary cursor-pointer group transition-all bg-card shadow-sm hover:shadow-md">
                        <h4 className="font-black text-lg group-hover:text-primary transition-colors">{customer.name}</h4>
                        <div className="mt-3 space-y-1">
                          <p className="text-xs text-muted-foreground flex justify-between">
                            <span>Total Lifetime:</span>
                            <span className="font-bold text-foreground">Rs. 1,245,000.00</span>
                          </p>
                          <p className="text-xs text-muted-foreground flex justify-between">
                            <span>Orders:</span>
                            <span className="font-bold text-foreground">14</span>
                          </p>
                        </div>
                        <div className="mt-4 pt-4 border-t text-[10px] font-black text-primary uppercase tracking-widest flex items-center gap-1">
                          View Activity <ExternalLink className="h-3 w-3" />
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Print Footer */}
        <div className="hidden print:flex flex-col items-center mt-12 text-center space-y-2">
          <div className="w-1/4 border-t-2 border-primary border-dashed pt-4" />
          <p className="text-base font-black uppercase tracking-[0.2em] text-primary">Certified Operational Report</p>
          <p className="text-sm text-muted-foreground max-w-xl italic font-medium">
            Official summary of sales activities for {COMPANY_CONFIG.name}. Values are final as per system logs.
          </p>
          {mounted && (
            <p className="text-[10px] text-muted-foreground pt-6 italic">Timestamp: {new Date().toLocaleString()}</p>
          )}
        </div>
      </div>
    </Shell>
  );
}
