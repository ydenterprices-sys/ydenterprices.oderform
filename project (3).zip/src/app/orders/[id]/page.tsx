
"use client";

import { use, useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Shell } from "@/components/layout/Shell";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { ChevronLeft, Package, User, Calendar, Tag, Printer, MapPin, Mail, Phone, Barcode, Trash2 } from "lucide-react";
import Link from "next/link";
import { COMPANY_CONFIG } from "@/lib/company-config";
import { useToast } from "@/hooks/use-toast";

// Mock Data
const MOCK_ORDERS_DETAILS: Record<string, any> = {
  "ORD-9281": {
    id: "ORD-9281",
    customer: "Acme Corp Solutions",
    customerId: "C001",
    email: "billing@acme.com",
    phone: "+1 555-0123",
    address: "123 Business Way, Suite 100, New York, NY 10001",
    date: "March 20, 2024",
    status: "Delivered",
    items: [
      { id: "1", name: "Ultra-Light Laptop", code: "PRO-001", size: "13-inch", quantity: 1, price: 129999.00 },
      { id: "3", name: "Mechanical Keyboard", code: "PRO-003", size: "Tenkeyless", quantity: 1, price: 15001.00 },
    ],
    subtotal: 145000.00,
    tax: 0.00,
    total: 145000.00
  },
  "ORD-9282": {
    id: "ORD-9282",
    customer: "Global Tech Inc",
    customerId: "C002",
    email: "finance@globaltech.io",
    phone: "+1 555-0124",
    address: "500 Innovation Blvd, San Francisco, CA 94103",
    date: "March 21, 2024",
    status: "Processing",
    items: [
      { id: "2", name: "Noise Cancelling Headphones", code: "PRO-002", size: "Premium Edition", quantity: 2, price: 29999.00 },
      { id: "4", name: "Ergonomic Mouse", code: "PRO-004", size: "Standard", quantity: 3, price: 9684.00 },
    ],
    subtotal: 89050.00,
    tax: 0.00,
    total: 89050.00
  },
  "ORD-9283": {
    id: "ORD-9283",
    customer: "Starlight Retailers",
    customerId: "C003",
    email: "orders@starlight.com",
    phone: "+1 555-0125",
    address: "88 Retail Row, Chicago, IL 60601",
    date: "March 21, 2024",
    status: "Pending",
    items: [
      { id: "5", name: "4K Monitor", code: "PRO-005", size: "32-inch", quantity: 5, price: 44900.00 },
      { id: "3", name: "Mechanical Keyboard", code: "PRO-003", size: "Full Size", quantity: 1, price: 15500.00 },
    ],
    subtotal: 240000.00,
    tax: 0.00,
    total: 240000.00
  }
};

export default function OrderDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const router = useRouter();
  const { toast } = useToast();
  const order = MOCK_ORDERS_DETAILS[id] || MOCK_ORDERS_DETAILS["ORD-9281"];
  const [mounted, setMounted] = useState(false);
  const [currentTime, setCurrentTime] = useState<string | null>(null);

  useEffect(() => {
    setMounted(true);
    setCurrentTime(new Date().toLocaleString());
  }, []);

  const handlePrint = () => {
    window.print();
  };

  const handleDeleteOrder = () => {
    toast({
      title: "Order Deleted",
      description: `Order ${order.id} has been permanently removed.`,
      variant: "destructive"
    });
    router.push("/orders");
  };

  return (
    <Shell>
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center justify-between print:hidden">
          <Link href="/orders" className="flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors">
            <ChevronLeft className="h-4 w-4" />
            Back to Orders
          </Link>
          <div className="flex gap-2">
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="outline" className="gap-2 text-destructive border-destructive hover:bg-destructive/10">
                  <Trash2 className="h-4 w-4" />
                  Delete Order
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                  <AlertDialogDescription>
                    This will permanently delete the order <strong>{order.id}</strong>. This action cannot be undone.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction onClick={handleDeleteOrder} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                    Confirm Delete
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
            <Button variant="default" className="gap-2 bg-primary hover:bg-primary/90 shadow-md" onClick={handlePrint}>
              <Printer className="h-4 w-4" />
              Print Invoice
            </Button>
          </div>
        </div>

        <div className="hidden print:block border-b-2 border-primary pb-8 mb-8">
          <div className="flex justify-between items-start">
            <div className="space-y-1">
              <h1 className="text-4xl font-black text-black font-headline tracking-tighter italic uppercase">{COMPANY_CONFIG.name}</h1>
              <p className="text-sm font-bold text-muted-foreground tracking-widest uppercase">Official Sales Invoice</p>
              <div className="mt-6 text-xs text-muted-foreground space-y-1">
                <p className="font-bold text-foreground">{COMPANY_CONFIG.legalName} HQ</p>
                <p>{COMPANY_CONFIG.address}</p>
                <p>{COMPANY_CONFIG.cityStateZip}</p>
                <p>{COMPANY_CONFIG.email} | {COMPANY_CONFIG.phone}</p>
              </div>
            </div>
            <div className="text-right">
              <div className="bg-primary text-white p-4 rounded-lg mb-4">
                <p className="text-[10px] font-bold uppercase tracking-widest opacity-80">Invoice Number</p>
                <p className="text-2xl font-black">{order.id}</p>
              </div>
              <div className="text-xs space-y-1">
                <p><span className="text-muted-foreground uppercase font-bold pr-2">Date:</span> {order.date}</p>
                <p><span className="text-muted-foreground uppercase font-bold pr-2">Status:</span> {order.status}</p>
              </div>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-12 mt-12">
            <div className="space-y-3">
              <p className="text-[10px] font-black uppercase text-primary border-b border-primary/20 pb-1">Bill To:</p>
              <div>
                <p className="font-bold text-xl">{order.customer}</p>
                <p className="text-sm text-muted-foreground leading-relaxed mt-1">{order.address}</p>
                <div className="flex flex-col gap-0.5 mt-2 text-xs text-muted-foreground">
                  <p className="flex items-center gap-1"><Mail className="h-3 w-3" /> {order.email}</p>
                  <p className="flex items-center gap-1"><Phone className="h-3 w-3" /> {order.phone}</p>
                </div>
              </div>
            </div>
            <div className="text-right space-y-3">
              <p className="text-[10px] font-black uppercase text-primary border-b border-primary/20 pb-1">Payment Information:</p>
              <div className="text-sm">
                <p className="font-bold text-lg">Net 30 Days</p>
                <p className="text-muted-foreground mt-1">Status: {order.status === 'Delivered' ? 'Paid in Full' : 'Due upon receipt'}</p>
              </div>
            </div>
          </div>
        </div>

        <div className="flex flex-col md:flex-row justify-between items-start gap-4 print:hidden">
          <div>
            <div className="flex items-center gap-3">
              <h1 className="text-3xl font-bold text-primary font-headline">{order.id}</h1>
              <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                order.status === 'Delivered' ? 'bg-green-100 text-green-700' : 
                order.status === 'Processing' ? 'bg-blue-100 text-blue-700' : 
                'bg-yellow-100 text-yellow-700'
              }`}>
                {order.status}
              </span>
            </div>
            <p className="text-muted-foreground flex items-center gap-2 mt-1">
              <Calendar className="h-4 w-4" />
              Placed on {order.date}
            </p>
          </div>
          <Card className="bg-primary text-white border-none px-8 py-6 shadow-xl">
            <p className="text-xs opacity-80 uppercase font-black tracking-widest">Total Amount</p>
            <p className="text-3xl font-black">Rs. {order.total.toLocaleString(undefined, { minimumFractionDigits: 2 })}</p>
          </Card>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="md:col-span-1 border-none shadow-md print:hidden">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <User className="h-5 w-5 text-primary" />
                Customer
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="font-bold text-lg">{order.customer}</div>
                <p className="text-xs text-muted-foreground mt-0.5">Customer ID: {order.customerId}</p>
              </div>
              <div className="flex items-start gap-2 text-xs text-muted-foreground">
                <MapPin className="h-4 w-4 shrink-0 text-primary" />
                <span>{order.address}</span>
              </div>
              <div className="space-y-1">
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Mail className="h-3 w-3" /> {order.email}
                </div>
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Phone className="h-3 w-3" /> {order.phone}
                </div>
              </div>
              <Button variant="link" className="p-0 h-auto text-xs mt-2" asChild>
                <Link href={`/customers/${order.customerId}`}>View Profile →</Link>
              </Button>
            </CardContent>
          </Card>

          <Card className="md:col-span-2 border-none shadow-md print:shadow-none print:border print:col-span-3">
            <CardHeader className="print:pb-4 border-b">
              <CardTitle className="text-lg flex items-center gap-2">
                <Package className="h-5 w-5 text-primary" />
                Order Manifest
              </CardTitle>
              <CardDescription className="print:hidden">Items included in this distribution.</CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader className="bg-muted/30">
                  <TableRow>
                    <TableHead className="font-bold">Code</TableHead>
                    <TableHead className="font-bold">Description</TableHead>
                    <TableHead className="font-bold">Size</TableHead>
                    <TableHead className="text-center font-bold">Qty</TableHead>
                    <TableHead className="text-right font-bold">Unit Price</TableHead>
                    <TableHead className="text-right font-bold">Total</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {order.items.map((item: any) => (
                    <TableRow key={`${item.id}-${item.size}`}>
                      <TableCell className="font-mono text-xs text-primary font-bold">
                        <div className="flex items-center gap-1">
                          <Barcode className="h-3 w-3 print:hidden" />
                          {item.code}
                        </div>
                      </TableCell>
                      <TableCell className="font-medium py-4">{item.name}</TableCell>
                      <TableCell>
                        <span className="px-2 py-0.5 rounded bg-muted text-[10px] font-bold uppercase">{item.size}</span>
                      </TableCell>
                      <TableCell className="text-center font-bold">{item.quantity}</TableCell>
                      <TableCell className="text-right font-mono">Rs. {item.price.toLocaleString(undefined, { minimumFractionDigits: 2 })}</TableCell>
                      <TableCell className="text-right font-bold font-mono">Rs. {(item.quantity * item.price).toLocaleString(undefined, { minimumFractionDigits: 2 })}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              <div className="p-8 space-y-3 bg-muted/10">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground uppercase text-[10px] font-black tracking-widest">Subtotal</span>
                  <span className="font-mono">Rs. {order.subtotal.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground uppercase text-[10px] font-black tracking-widest">Tax (0.00%)</span>
                  <span className="font-mono">Rs. {order.tax.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                </div>
                <div className="flex justify-between items-center font-black text-2xl pt-6 border-t-2 border-primary">
                  <span className="uppercase text-sm tracking-widest">Grand Total</span>
                  <span className="text-primary font-mono">Rs. {order.total.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div className="hidden print:flex flex-col items-center pt-32 text-center">
          <div className="w-1/2 border-t border-dashed mb-4" />
          <p className="font-black text-primary uppercase text-xs tracking-[0.2em] mb-2">Authorized Signature</p>
          <p className="text-[10px] text-muted-foreground mt-12 max-w-lg">
            Thank you for your business with <span className="font-bold text-primary">{COMPANY_CONFIG.name}</span>. 
            Payment is due according to the terms specified above. For any discrepancies, please contact support within 7 days.
          </p>
          {mounted && currentTime && (
            <p className="mt-8 italic text-[8px] text-muted-foreground">Document generated on {currentTime}</p>
          )}
        </div>
      </div>
    </Shell>
  );
}
