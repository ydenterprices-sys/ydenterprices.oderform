"use client";

import { useState } from "react";
import { Shell } from "@/components/layout/Shell";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Search, Plus, Phone, Mail, MapPin, ExternalLink, Truck } from "lucide-react";
import Link from "next/link";

// Mock data
const MOCK_SUPPLIERS = [
  { id: "S001", name: "Apex Tech Supplies", contact: "Alice Wong", email: "sales@apextech.com", phone: "+94 11 234 5678", city: "Colombo" },
  { id: "S002", name: "Global Logistics Ltd", contact: "Mark Stevens", email: "support@globallog.lk", phone: "+94 11 555 1234", city: "Kandy" },
  { id: "S003", name: "Starlight Manufacturing", contact: "Rita Perera", email: "rita@starlight.lk", phone: "+94 31 999 0000", city: "Negombo" },
];

export default function SuppliersPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [suppliers] = useState(MOCK_SUPPLIERS);

  const filteredSuppliers = suppliers.filter(
    (s) => 
      s.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
      s.contact.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <Shell>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-primary font-headline">Supplier Directory</h1>
            <p className="text-muted-foreground">Manage your supply chain and vendor contacts.</p>
          </div>
          <Link href="/suppliers/new">
            <Button className="w-full sm:w-auto gap-2">
              <Plus className="h-4 w-4" />
              Add Supplier
            </Button>
          </Link>
        </div>

        <div className="relative">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input 
            placeholder="Search by supplier name, contact, or ID..." 
            className="pl-10 h-12 shadow-sm border-primary/20"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        <Card className="border-none shadow-md overflow-hidden">
          <Table>
            <TableHeader className="bg-muted/50">
              <TableRow>
                <TableHead className="w-[100px]">ID</TableHead>
                <TableHead>Supplier & Contact</TableHead>
                <TableHead>Communication</TableHead>
                <TableHead>Location</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredSuppliers.map((supplier) => (
                <TableRow key={supplier.id} className="hover:bg-primary/5 transition-colors">
                  <TableCell className="font-mono text-xs font-semibold text-primary">{supplier.id}</TableCell>
                  <TableCell>
                    <div className="flex flex-col">
                      <span className="font-bold text-lg">{supplier.name}</span>
                      <span className="text-sm text-muted-foreground">{supplier.contact}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex flex-col gap-1">
                      <div className="flex items-center gap-2 text-xs">
                        <Mail className="h-3 w-3 text-accent" />
                        {supplier.email}
                      </div>
                      <div className="flex items-center gap-2 text-xs">
                        <Phone className="h-3 w-3 text-accent" />
                        {supplier.phone}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2 text-sm">
                      <MapPin className="h-3 w-3 text-muted-foreground" />
                      {supplier.city}
                    </div>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="sm" asChild>
                      <Link href={`/suppliers/${supplier.id}`} className="gap-2">
                        View Details
                        <ExternalLink className="h-3 w-3" />
                      </Link>
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
              {filteredSuppliers.length === 0 && (
                <TableRow>
                  <TableCell colSpan={5} className="h-24 text-center text-muted-foreground">
                    No suppliers found matching your search criteria.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </Card>
      </div>
    </Shell>
  );
}
