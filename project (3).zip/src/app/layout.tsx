import type { Metadata, Viewport } from 'next';
import './globals.css';
import { Toaster } from '@/components/ui/toaster';
import { COMPANY_CONFIG } from '@/lib/company-config';
import { PasscodeGuard } from '@/components/auth/PasscodeGuard';
import { FirebaseClientProvider } from '@/firebase/client-provider';

export const metadata: Metadata = {
  title: `${COMPANY_CONFIG.name} - Order Hub`,
  description: `Product ordering and management system for ${COMPANY_CONFIG.legalName}.`,
  appleWebApp: {
    capable: true,
    statusBarStyle: 'default',
    title: COMPANY_CONFIG.name,
  },
  formatDetection: {
    telephone: false,
  },
};

export const viewport: Viewport = {
  themeColor: '#2563eb',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet" />
        <link rel="manifest" href="/manifest.json" />
      </head>
      <body className="font-body antialiased min-h-screen">
        <FirebaseClientProvider>
          <PasscodeGuard>
            {children}
          </PasscodeGuard>
        </FirebaseClientProvider>
        <Toaster />
      </body>
    </html>
  );
}
