import { Shell } from "@/components/layout/Shell";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Package, Users, ShoppingCart, TrendingUp, Settings, Truck } from "lucide-react";
import Link from "next/link";
import { COMPANY_CONFIG } from "@/lib/company-config";

export default function DashboardPage() {
  const stats = [
    { label: "Daily Sales", value: "Rs. 4,280", icon: TrendingUp, color: "text-green-600", trend: "+12.5%" },
    { label: "Orders Today", value: "24", icon: ShoppingCart, color: "text-blue-600", trend: "+4" },
    { label: "Active Customers", value: "156", icon: Users, color: "text-purple-600", trend: "+2" },
    { label: "Active Suppliers", value: "12", icon: Truck, color: "text-blue-500", trend: "+1" },
  ];

  return (
    <Shell>
      <div className="space-y-8">
        <div>
          <h1 className="text-3xl font-bold font-headline text-primary">Operational Overview</h1>
          <p className="text-muted-foreground">Welcome back. Here is what is happening at {COMPANY_CONFIG.name} today.</p>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {stats.map((stat) => (
            <Card key={stat.label} className="border-none shadow-md">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">{stat.label}</CardTitle>
                <stat.icon className={`h-4 w-4 ${stat.color}`} />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stat.value}</div>
                <p className="text-xs text-muted-foreground mt-1">
                  <span className={stat.trend.startsWith('+') ? "text-green-600" : "text-muted-foreground"}>
                    {stat.trend}
                  </span> from yesterday
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          <Card className="border-none shadow-md">
            <CardHeader>
              <CardTitle>Recent Orders</CardTitle>
              <CardDescription>Latest transactions across your customer base.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="flex items-center justify-between border-b pb-4 last:border-0 last:pb-0">
                    <div className="flex flex-col">
                      <span className="font-semibold">Customer #{1024 + i}</span>
                      <span className="text-xs text-muted-foreground">3 items • Today, 2:45 PM</span>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-primary">Rs. 345.00</div>
                      <div className="text-xs text-accent-foreground bg-accent/20 px-2 py-0.5 rounded-full inline-block">Processing</div>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-6">
                <Link href="/orders" className="text-sm font-medium text-primary hover:underline">View all orders →</Link>
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-md">
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
              <CardDescription>Manage your products, customers, and supply chain.</CardDescription>
            </CardHeader>
            <CardContent className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Link href="/products/new" className="block p-4 rounded-lg border border-dashed border-primary/30 bg-primary/5 hover:bg-primary/10 transition-colors">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-primary rounded-full text-white">
                    <Package className="h-4 w-4" />
                  </div>
                  <div>
                    <p className="font-semibold text-sm">New Product</p>
                    <p className="text-[10px] text-muted-foreground">Add inventory items.</p>
                  </div>
                </div>
              </Link>
              <Link href="/customers/new" className="block p-4 rounded-lg border border-dashed border-accent/30 bg-accent/5 hover:bg-accent/10 transition-colors">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-accent rounded-full text-accent-foreground">
                    <Users className="h-4 w-4" />
                  </div>
                  <div>
                    <p className="font-semibold text-sm">Register Customer</p>
                    <p className="text-[10px] text-muted-foreground">Add business contacts.</p>
                  </div>
                </div>
              </Link>
              <Link href="/suppliers/new" className="block p-4 rounded-lg border border-dashed border-blue-300 bg-blue-50 hover:bg-blue-100 transition-colors">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-blue-500 rounded-full text-white">
                    <Truck className="h-4 w-4" />
                  </div>
                  <div>
                    <p className="font-semibold text-sm">Add Supplier</p>
                    <p className="text-[10px] text-muted-foreground">Manage your vendors.</p>
                  </div>
                </div>
              </Link>
              <Link href="/settings" className="block p-4 rounded-lg border border-dashed border-muted-foreground/30 bg-muted/5 hover:bg-muted/10 transition-colors">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-muted-foreground rounded-full text-white">
                    <Settings className="h-4 w-4" />
                  </div>
                  <div>
                    <p className="font-semibold text-sm">Settings</p>
                    <p className="text-[10px] text-muted-foreground">Company profile.</p>
                  </div>
                </div>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    </Shell>
  );
}
