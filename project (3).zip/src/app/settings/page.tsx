"use client";

import { useState } from "react";
import { Shell } from "@/components/layout/Shell";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Building2, Mail, Phone, MapPin, Globe, Save, Info, Lock } from "lucide-react";
import { COMPANY_CONFIG } from "@/lib/company-config";

export default function SettingsPage() {
  const { toast } = useToast();
  const [config, setConfig] = useState(COMPANY_CONFIG);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: "Settings Saved",
      description: "Company details have been updated (simulated). Update src/lib/company-config.ts for permanent changes.",
    });
  };

  const handleLockSystem = () => {
    localStorage.removeItem("yd_passcode_verified");
    toast({
      title: "System Locked",
      description: "You have been signed out. Please refresh to re-authenticate.",
    });
    // Force a reload to trigger the PasscodeGuard
    window.location.reload();
  };

  return (
    <Shell>
      <div className="max-w-4xl mx-auto space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-primary font-headline">System Settings</h1>
          <p className="text-muted-foreground">Manage your company profile and application defaults.</p>
        </div>

        <form onSubmit={handleSave} className="space-y-6">
          <Card className="border-none shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Building2 className="h-5 w-5 text-primary" />
                Company Profile
              </CardTitle>
              <CardDescription>
                These details are used across invoices, reports, and the navigation bar.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Display Name</Label>
                  <Input 
                    id="name" 
                    value={config.name} 
                    onChange={(e) => setConfig({...config, name: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="legalName">Legal Entity Name</Label>
                  <Input 
                    id="legalName" 
                    value={config.legalName}
                    onChange={(e) => setConfig({...config, legalName: e.target.value})}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="address">Headquarters Address</Label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input 
                    id="address" 
                    className="pl-9"
                    value={config.address}
                    onChange={(e) => setConfig({...config, address: e.target.value})}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="email">Support Email</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input 
                      id="email" 
                      type="email"
                      className="pl-9"
                      value={config.email}
                      onChange={(e) => setConfig({...config, email: e.target.value})}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">Contact Phone</Label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input 
                      id="phone" 
                      type="tel"
                      className="pl-9"
                      value={config.phone}
                      onChange={(e) => setConfig({...config, phone: e.target.value})}
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="website">Website URL</Label>
                <div className="relative">
                  <Globe className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input 
                    id="website" 
                    className="pl-9"
                    value={config.website}
                    onChange={(e) => setConfig({...config, website: e.target.value})}
                  />
                </div>
              </div>
            </CardContent>
            <CardFooter className="bg-muted/30 py-4 flex flex-col items-start gap-4">
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <Info className="h-4 w-4" />
                <span>To apply these changes permanently to the code, edit <code>src/lib/company-config.ts</code>.</span>
              </div>
              <Button type="submit" className="w-full sm:w-auto gap-2">
                <Save className="h-4 w-4" />
                Save Changes
              </Button>
            </CardFooter>
          </Card>
        </form>

        <Card className="border-none shadow-lg border-t-4 border-destructive">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2 text-destructive">
              <Lock className="h-5 w-5" />
              Security Management
            </CardTitle>
            <CardDescription>
              Manage your local session and security preferences.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">
              Locking the system will clear your local verification and require the passcode to be re-entered.
            </p>
            <Button variant="destructive" onClick={handleLockSystem} className="gap-2">
              <Lock className="h-4 w-4" />
              Lock System & Sign Out
            </Button>
          </CardContent>
        </Card>
      </div>
    </Shell>
  );
}
