"use client";

import { useState, useEffect } from "react";
import { Shell } from "@/components/layout/Shell";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Search, Plus, Edit, Package, Barcode, Printer, Image as ImageIcon } from "lucide-react";
import Link from "next/link";
import Image from "next/image";
import { COMPANY_CONFIG } from "@/lib/company-config";

// Mock data
const INITIAL_PRODUCTS = [
  { 
    id: "1", 
    name: "Ultra-Light Laptop", 
    code: "PRO-001", 
    photo: "https://picsum.photos/seed/elec1/600/400", 
    category: "Electronics",
    variants: [
      { size: "13-inch", price: 129999.00 },
      { size: "15-inch", price: 149999.00 }
    ]
  },
  { 
    id: "2", 
    name: "Noise Cancelling Headphones", 
    code: "PRO-002", 
    photo: "https://picsum.photos/seed/elec2/600/400", 
    category: "Electronics",
    variants: [
      { size: "Standard", price: 29999.00 },
      { size: "Premium Edition", price: 39999.00 }
    ]
  },
  { 
    id: "3", 
    name: "Mechanical Keyboard", 
    code: "PRO-003", 
    photo: "https://picsum.photos/seed/elec3/600/400", 
    category: "Peripherals",
    variants: [
      { size: "60% Compact", price: 12500.00 },
      { size: "Full Size", price: 16500.00 }
    ]
  },
  { 
    id: "4", 
    name: "Ergonomic Mouse", 
    code: "PRO-004", 
    photo: "https://picsum.photos/seed/elec4/600/400", 
    category: "Peripherals",
    variants: [
      { size: "Standard", price: 7999.00 },
      { size: "XL Performance", price: 9999.00 }
    ]
  },
  { 
    id: "5", 
    name: "4K Monitor", 
    code: "PRO-005", 
    photo: "https://picsum.photos/seed/elec5/600/400", 
    category: "Displays",
    variants: [
      { size: "27-inch", price: 44900.00 },
      { size: "32-inch", price: 59900.00 }
    ]
  },
];

export default function ProductsPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [products] = useState(INITIAL_PRODUCTS);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  const filteredProducts = products.filter(
    (p) => 
      p.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
      p.code.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handlePrintCatalog = () => {
    window.print();
  };

  return (
    <Shell>
      <div className="space-y-6">
        {/* Header - Actions Hidden in Print */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 print:hidden">
          <div>
            <h1 className="text-3xl font-bold text-primary font-headline">Product Catalog</h1>
            <p className="text-muted-foreground">Manage and search your products.</p>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" className="gap-2 border-primary text-primary hover:bg-primary hover:text-white shadow-sm" onClick={handlePrintCatalog}>
              <Printer className="h-4 w-4" />
              Print Catalog
            </Button>
            <Link href="/products/new">
              <Button className="w-full sm:w-auto gap-2">
                <Plus className="h-4 w-4" />
                Add Product
              </Button>
            </Link>
          </div>
        </div>

        {/* Print-Only Catalog Header */}
        <div className="hidden print:block border-b-4 border-primary pb-8 mb-12">
          <div className="flex justify-between items-end">
            <div>
              <h1 className="text-5xl font-black text-black font-headline italic tracking-tighter uppercase">{COMPANY_CONFIG.name}</h1>
              <p className="text-sm font-bold text-muted-foreground tracking-[0.3em] mt-2 uppercase">Official Product Catalog</p>
            </div>
            <div className="text-right">
              <p className="text-xs font-black uppercase text-primary">Catalog Edition</p>
              <p className="text-2xl font-bold">{mounted ? new Date().toLocaleDateString('en-US', { month: 'long', year: 'numeric' }) : ''}</p>
            </div>
          </div>
          <div className="mt-8 text-[10px] text-muted-foreground leading-relaxed italic">
            This catalog represents the current distribution inventory for {COMPANY_CONFIG.name}. 
            All prices and availability are subject to change without prior notice.
          </div>
        </div>

        {/* Search Bar - Hidden in Print */}
        <div className="relative print:hidden">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input 
            placeholder="Search by product name or code..." 
            className="pl-10 h-12 text-lg shadow-sm border-primary/20 focus:ring-primary"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        {filteredProducts.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 print:grid-cols-2 print:gap-8">
            {filteredProducts.map((product) => {
              const minPrice = Math.min(...product.variants.map(v => v.price));
              const maxPrice = Math.max(...product.variants.map(v => v.price));
              
              return (
                <Card key={product.id} className="overflow-hidden border-none shadow-md hover:shadow-lg transition-all group print:shadow-none print:border print:rounded-none">
                  <div className="relative aspect-video overflow-hidden bg-muted print:aspect-[4/3]">
                    <Image 
                      src={product.photo} 
                      alt={product.name}
                      fill
                      className="object-cover transition-transform group-hover:scale-105"
                    />
                    <div className="absolute top-2 right-2 bg-white/90 backdrop-blur px-2 py-1 rounded text-xs font-bold shadow-sm print:bg-primary print:text-white">
                      {product.code}
                    </div>
                  </div>
                  <CardHeader className="p-4 pb-2">
                    <div className="text-[10px] font-black uppercase text-primary tracking-widest mb-1 hidden print:block">
                      {product.category || 'General Merchandise'}
                    </div>
                    <CardTitle className="text-lg line-clamp-1 group-hover:text-primary transition-colors print:text-xl print:font-black">
                      {product.name}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-4 pt-0">
                    <div className="flex flex-col gap-2 mt-1">
                      <div className="flex items-center justify-between">
                        <span className="text-xl font-bold text-primary print:text-2xl print:text-foreground">
                          {minPrice === maxPrice ? `Rs. ${minPrice.toLocaleString()}` : `Rs. ${minPrice.toLocaleString()} - ${maxPrice.toLocaleString()}`}
                        </span>
                        <div className="flex items-center gap-1 text-xs text-muted-foreground print:text-primary print:font-bold">
                          <Barcode className="h-3 w-3" />
                          {product.code}
                        </div>
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {product.variants.map(v => (
                          <span key={v.size} className="text-[8px] font-bold uppercase px-1.5 py-0.5 rounded bg-muted text-muted-foreground">
                            {v.size}
                          </span>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="p-4 pt-0 flex gap-2 print:hidden">
                    <Button variant="outline" size="sm" className="flex-1 gap-2">
                      <Edit className="h-3 w-3" />
                      Edit
                    </Button>
                  </CardFooter>
                </Card>
              );
            })}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-20 bg-card rounded-xl shadow-sm border border-dashed print:hidden">
            <Package className="h-12 w-12 text-muted-foreground mb-4 opacity-20" />
            <p className="text-xl font-medium text-muted-foreground">No products found matching your search.</p>
            <Button variant="link" onClick={() => setSearchTerm("")}>Clear search</Button>
          </div>
        )}

        {/* Print-Only Footer */}
        <div className="hidden print:flex flex-col items-center mt-20 pt-10 border-t border-dashed text-center">
          <p className="text-[10px] font-black uppercase tracking-[0.3em] text-primary">{COMPANY_CONFIG.legalName} DISTRIBUTION NETWORK</p>
          <p className="text-[8px] text-muted-foreground max-w-sm mt-4 italic leading-relaxed">
            For ordering and bulk distribution inquiries, please contact our logistics center.
            Prices listed are MSRP.
          </p>
          {mounted && (
            <p className="text-[8px] text-muted-foreground mt-8 opacity-50 italic">
              Generated on {new Date().toLocaleString()}
            </p>
          )}
        </div>
      </div>
    </Shell>
  );
}
