"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Shell } from "@/components/layout/Shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { ChevronLeft, Sparkles, Package, ImageIcon, Loader2, Truck } from "lucide-react";
import { generateProductDescription } from "@/ai/flows/generate-product-description-flow";
import { useToast } from "@/hooks/use-toast";
import Link from "next/link";

// Mock Suppliers
const MOCK_SUPPLIERS = [
  { id: "S001", name: "Apex Tech Supplies" },
  { id: "S002", name: "Global Logistics Ltd" },
  { id: "S003", name: "Starlight Manufacturing" },
];

export default function NewProductPage() {
  const router = useRouter();
  const { toast } = useToast();
  const [isGenerating, setIsGenerating] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    code: "",
    price: "",
    category: "Electronics",
    features: "",
    description: "",
    supplierId: "",
    photo: "https://picsum.photos/seed/newproduct/600/400"
  });

  const handleGenerateDescription = async () => {
    if (!formData.name || !formData.code) {
      toast({
        title: "Missing Information",
        description: "Please enter at least a name and product code to generate a description.",
        variant: "destructive"
      });
      return;
    }

    setIsGenerating(true);
    try {
      const result = await generateProductDescription({
        productName: formData.name,
        productCode: formData.code,
        category: formData.category,
        features: formData.features.split(",").map(f => f.trim()).filter(f => f !== ""),
      });
      
      setFormData(prev => ({ ...prev, description: result.description }));
      toast({
        title: "Success",
        description: "Product description generated successfully!",
      });
    } catch (error) {
      console.error(error);
      toast({
        title: "Error",
        description: "Failed to generate product description.",
        variant: "destructive"
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: "Product Saved",
      description: `${formData.name} has been added to the catalog.`,
    });
    router.push("/products");
  };

  return (
    <Shell>
      <div className="max-w-3xl mx-auto space-y-6">
        <Link href="/products" className="flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors">
          <ChevronLeft className="h-4 w-4" />
          Back to Catalog
        </Link>

        <div className="space-y-2">
          <h1 className="text-3xl font-bold text-primary font-headline">Add New Product</h1>
          <p className="text-muted-foreground">Fill in the details to list a new item in your inventory.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <Card className="border-none shadow-lg">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Package className="h-5 w-5 text-primary" />
                Basic Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Product Name</Label>
                  <Input 
                    id="name" 
                    required 
                    placeholder="e.g. Premium Wireless Mouse" 
                    value={formData.name}
                    onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="code">Product Code</Label>
                  <Input 
                    id="code" 
                    required 
                    placeholder="e.g. WM-2024-X" 
                    value={formData.code}
                    onChange={(e) => setFormData(prev => ({ ...prev, code: e.target.value }))}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="price">Base Unit Price (Rs.)</Label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-bold text-muted-foreground">Rs.</span>
                    <Input 
                      id="price" 
                      type="number" 
                      step="0.01" 
                      required 
                      className="pl-10"
                      placeholder="0.00"
                      value={formData.price}
                      onChange={(e) => setFormData(prev => ({ ...prev, price: e.target.value }))}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="category">Category</Label>
                  <Input 
                    id="category" 
                    placeholder="e.g. Peripherals"
                    value={formData.category}
                    onChange={(e) => setFormData(prev => ({ ...prev, category: e.target.value }))}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="supplier">Assigned Supplier</Label>
                <div className="flex items-center gap-2">
                  <Truck className="h-4 w-4 text-muted-foreground" />
                  <Select 
                    value={formData.supplierId} 
                    onValueChange={(val) => setFormData(prev => ({ ...prev, supplierId: val }))}
                  >
                    <SelectTrigger id="supplier">
                      <SelectValue placeholder="Select a supplier..." />
                    </SelectTrigger>
                    <SelectContent>
                      {MOCK_SUPPLIERS.map((s) => (
                        <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <p className="text-[10px] text-muted-foreground">
                  New supplier? <Link href="/suppliers/new" className="text-primary hover:underline">Add them here</Link>
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="photo">Photo URL</Label>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <ImageIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input 
                      id="photo" 
                      className="pl-9"
                      value={formData.photo}
                      onChange={(e) => setFormData(prev => ({ ...prev, photo: e.target.value }))}
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg">
            <CardHeader className="flex flex-row items-center justify-between space-y-0">
              <CardTitle className="text-lg flex items-center gap-2">
                <Sparkles className="h-5 w-5 text-accent" />
                Description & AI Assistant
              </CardTitle>
              <Button 
                type="button" 
                variant="outline" 
                size="sm" 
                className="gap-2 border-accent text-accent hover:bg-accent hover:text-white"
                onClick={handleGenerateDescription}
                disabled={isGenerating}
              >
                {isGenerating ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
                AI Generate
              </Button>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="features">Key Features (comma separated)</Label>
                <Input 
                  id="features" 
                  placeholder="High-speed, Wireless, Ergonomic, RGB..." 
                  value={formData.features}
                  onChange={(e) => setFormData(prev => ({ ...prev, features: e.target.value }))}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">Product Description</Label>
                <Textarea 
                  id="description" 
                  className="min-h-[150px]"
                  placeholder="Tell customers about your product..." 
                  value={formData.description}
                  onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                />
              </div>
            </CardContent>
            <CardFooter className="bg-muted/30 py-4 flex justify-end gap-3">
              <Button type="button" variant="ghost" onClick={() => router.push("/products")}>Cancel</Button>
              <Button type="submit" className="px-8">Save Product</Button>
            </CardFooter>
          </Card>
        </form>
      </div>
    </Shell>
  );
}
