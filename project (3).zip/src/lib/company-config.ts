export const COMPANY_CONFIG = {
  name: "YD ENETRPRICES",
  legalName: "YD ENETRPRICES",
  address: "123 Distributor Lane, Industrial Hub",
  cityStateZip: "City Center, State 10021",
  email: "support@ydenterprices.com",
  phone: "+1 (800) YD-ORDER",
  website: "www.ydenterprices.com",
  tagline: "Quality Distribution & Logistics",
};
