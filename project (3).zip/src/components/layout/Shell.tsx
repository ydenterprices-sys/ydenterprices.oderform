import { Navbar } from "./Navbar";
import { BottomNav } from "./BottomNav";
import { COMPANY_CONFIG } from "@/lib/company-config";

export function Shell({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen flex-col bg-background">
      <Navbar />
      <main className="flex-1 container mx-auto py-8 pb-24 md:pb-8 px-4 sm:px-6 lg:px-8">
        {children}
      </main>
      <footer className="hidden md:block border-t bg-card py-6">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          &copy; {new Date().getFullYear()} {COMPANY_CONFIG.legalName}. All rights reserved.
        </div>
      </footer>
      <BottomNav />
    </div>
  );
}
