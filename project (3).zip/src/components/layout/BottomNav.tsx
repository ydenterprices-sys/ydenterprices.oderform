"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Package, Users, ShoppingCart, BarChart3, PlusCircle, Settings, Truck } from "lucide-react";
import { cn } from "@/lib/utils";

export function BottomNav() {
  const pathname = usePathname();

  const navItems = [
    { name: "Home", href: "/", icon: BarChart3 },
    { name: "Products", href: "/products", icon: Package },
    { name: "New", href: "/orders/new", icon: PlusCircle, highlight: true },
    { name: "Suppliers", href: "/suppliers", icon: Truck },
    { name: "Orders", href: "/orders", icon: ShoppingCart },
  ];

  return (
    <nav className="fixed bottom-0 left-0 z-50 w-full border-t bg-card pb-safe md:hidden print:hidden">
      <div className="grid h-16 grid-cols-5 items-center justify-items-center">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = pathname === item.href;
          
          if (item.highlight) {
            return (
              <Link key={item.href} href={item.href} className="relative -top-4">
                <div className="flex h-14 w-14 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-lg ring-4 ring-background">
                  <Icon className="h-6 w-6" />
                </div>
              </Link>
            );
          }

          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex flex-col items-center justify-center gap-1 text-[10px] font-medium transition-colors",
                isActive ? "text-primary" : "text-muted-foreground hover:text-primary"
              )}
            >
              <Icon className={cn("h-5 w-5", isActive && "stroke-[2.5px]")} />
              {item.name}
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
