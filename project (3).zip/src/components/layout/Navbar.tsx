"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Package, Users, ShoppingCart, BarChart3, PlusCircle, Settings, Truck, LogOut } from "lucide-react";
import { cn } from "@/lib/utils";
import { COMPANY_CONFIG } from "@/lib/company-config";
import { Button } from "@/components/ui/button";

export function Navbar() {
  const pathname = usePathname();

  const navItems = [
    { name: "Dashboard", href: "/", icon: BarChart3 },
    { name: "Products", href: "/products", icon: Package },
    { name: "Customers", href: "/customers", icon: Users },
    { name: "Suppliers", href: "/suppliers", icon: Truck },
    { name: "Orders", href: "/orders", icon: ShoppingCart },
    { name: "Settings", href: "/settings", icon: Settings },
  ];

  const handleSignOut = () => {
    localStorage.removeItem("yd_passcode_verified");
    window.location.reload();
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b bg-card shadow-sm print:hidden">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        <div className="flex items-center gap-2">
          <Link href="/" className="flex items-center space-x-2">
            <span className="text-xl font-bold text-black font-headline tracking-tight uppercase">
              {COMPANY_CONFIG.name}
            </span>
          </Link>
        </div>

        <nav className="hidden md:flex items-center space-x-6">
          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "flex items-center gap-2 text-sm font-medium transition-colors hover:text-primary",
                  pathname === item.href ? "text-primary" : "text-muted-foreground"
                )}
              >
                <Icon className="h-4 w-4" />
                {item.name}
              </Link>
            );
          })}
        </nav>

        <div className="flex items-center gap-4">
          <Link href="/orders/new" className="hidden md:block">
            <button className="inline-flex items-center gap-2 rounded-md bg-accent px-4 py-2 text-sm font-semibold text-accent-foreground shadow-sm hover:opacity-90 transition-all">
              <PlusCircle className="h-4 w-4" />
              New Order
            </button>
          </Link>
          
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={handleSignOut}
            className="text-muted-foreground hover:text-destructive"
            title="Sign Out"
          >
            <LogOut className="h-5 w-5" />
          </Button>

          <Link href="/settings" className="md:hidden">
            <Settings className="h-6 w-6 text-muted-foreground" />
          </Link>
        </div>
      </div>
    </header>
  );
}
