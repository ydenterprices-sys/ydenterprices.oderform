"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Lock, LogIn, AlertCircle } from "lucide-react";
import { COMPANY_CONFIG } from "@/lib/company-config";

const PASSCODE = "YD123";

export function PasscodeGuard({ children }: { children: React.ReactNode }) {
  const [isVerified, setIsVerified] = useState<boolean>(false);
  const [mounted, setMounted] = useState(false);
  const [input, setInput] = useState("");
  const [error, setError] = useState(false);

  useEffect(() => {
    setMounted(true);
    const verified = localStorage.getItem("yd_passcode_verified") === "true";
    setIsVerified(verified);
  }, []);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (input === PASSCODE) {
      localStorage.setItem("yd_passcode_verified", "true");
      setIsVerified(true);
      setError(false);
    } else {
      setError(true);
      setInput("");
    }
  };

  // Avoid hydration mismatch by rendering a skeleton or background during initial load
  if (!mounted) {
    return <div className="min-h-screen bg-background" />;
  }

  if (!isVerified) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4 sm:p-6">
        <div className="w-full max-w-md space-y-8 text-center">
          <div className="space-y-2">
            <h1 className="text-4xl font-black text-primary italic font-headline uppercase tracking-tighter">
              {COMPANY_CONFIG.name}
            </h1>
            <p className="text-muted-foreground font-medium tracking-widest uppercase text-xs">
              Secure Distribution Hub
            </p>
          </div>

          <Card className="border-none shadow-2xl">
            <CardHeader className="pt-8">
              <div className="mx-auto w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                <Lock className="h-6 w-6 text-primary" />
              </div>
              <CardTitle className="text-2xl font-bold">Authentication Required</CardTitle>
              <CardDescription>
                Enter your secure passcode to access the {COMPANY_CONFIG.name} operational system.
              </CardDescription>
            </CardHeader>
            <CardContent className="px-8">
              <form onSubmit={handleLogin} className="space-y-4">
                <div className="space-y-2">
                  <Input
                    type="password"
                    placeholder="Enter passcode"
                    className={`h-12 text-center text-xl tracking-[0.5em] font-black ${
                      error ? "border-destructive ring-destructive" : ""
                    }`}
                    value={input}
                    onChange={(e) => {
                      setInput(e.target.value);
                      if (error) setError(false);
                    }}
                    autoFocus
                  />
                  {error && (
                    <p className="text-destructive text-xs font-bold flex items-center justify-center gap-1">
                      <AlertCircle className="h-3 w-3" />
                      Invalid passcode. Please try again.
                    </p>
                  )}
                </div>
                <Button type="submit" className="w-full h-12 gap-2 font-bold text-lg">
                  <LogIn className="h-5 w-5" />
                  Unlock System
                </Button>
              </form>
            </CardContent>
            <CardFooter className="pb-8 pt-4">
              <p className="text-[10px] text-muted-foreground mx-auto uppercase font-bold tracking-tighter opacity-50">
                Unauthorized access is strictly prohibited
              </p>
            </CardFooter>
          </Card>
        </div>
      </div>
    );
  }

  return <>{children}</>;
}
