export const firebaseConfig = {
  "projectId": "studio-4393575000-f7ffd",
  "appId": "1:869108186110:web:a94c0d29c38f7beb311eaf",
  "apiKey": "AIzaSyAYugFKAkA-XmF9Iglfcfi0lcqZ_PT0K0g",
  "authDomain": "studio-4393575000-f7ffd.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "869108186110"
};
