'use server';
/**
 * @fileOverview A Genkit flow for generating detailed product descriptions for YD Enterprices.
 *
 * - generateProductDescription - A function that generates a product description.
 * - GenerateProductDescriptionInput - The input type for the generateProductDescription function.
 * - GenerateProductDescriptionOutput - The return type for the generateProductDescription function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GenerateProductDescriptionInputSchema = z.object({
  productName: z.string().describe('The name of the product.'),
  productCode: z.string().describe('The unique product code.'),
  category: z.string().optional().describe('The category the product belongs to (e.g., Electronics, Apparel, Home Goods).'),
  features: z.array(z.string()).optional().describe('A list of key features of the product.'),
});
export type GenerateProductDescriptionInput = z.infer<typeof GenerateProductDescriptionInputSchema>;

const GenerateProductDescriptionOutputSchema = z.object({
  description: z.string().describe('A detailed and appealing product description.'),
});
export type GenerateProductDescriptionOutput = z.infer<typeof GenerateProductDescriptionOutputSchema>;

export async function generateProductDescription(input: GenerateProductDescriptionInput): Promise<GenerateProductDescriptionOutput> {
  return generateProductDescriptionFlow(input);
}

const productDescriptionPrompt = ai.definePrompt({
  name: 'productDescriptionPrompt',
  input: {schema: GenerateProductDescriptionInputSchema},
  output: {schema: GenerateProductDescriptionOutputSchema},
  prompt: `You are an expert marketing copywriter for "YD Enterprices". Your task is to create a detailed, appealing, and compelling product description based on the provided product information.

Product Name: {{{productName}}}
Product Code: {{{productCode}}}
{{#if category}}Category: {{{category}}}{{/if}}
{{#if features}}
Key Features:
{{#each features}}- {{{this}}}
{{/each}}
{{/if}}

Based on the above information, generate a professional and engaging product description that highlights its benefits and unique selling points for YD Enterprices. The description should be at least 3-5 sentences long.`,
});

const generateProductDescriptionFlow = ai.defineFlow(
  {
    name: 'generateProductDescriptionFlow',
    inputSchema: GenerateProductDescriptionInputSchema,
    outputSchema: GenerateProductDescriptionOutputSchema,
  },
  async (input) => {
    const {output} = await productDescriptionPrompt(input);
    return output!;
  }
);
